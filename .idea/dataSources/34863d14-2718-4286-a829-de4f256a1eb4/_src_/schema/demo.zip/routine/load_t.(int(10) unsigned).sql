CREATE PROCEDURE load_t(IN count INT(10) UNSIGNED)
  begin
	set @c = 0;
	while @c < count DO 
		insert into t select null,repeat(char(97+RAND()), 10);
		set @c = @c + 1;
	end while;
end;
