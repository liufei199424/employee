CREATE PROCEDURE load_t3(IN count INT(10) UNSIGNED)
  begin
	declare s int unsigned default 1;
	declare c varchar(7000) default repeat('a', 7000);
	while s <= count do
		insert into t3 select null,c;
		set s = s + 1;
	end while;
end;
